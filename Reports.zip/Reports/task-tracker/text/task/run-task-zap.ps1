﻿param([string]$Target = "http://host.docker.internal:8082/")

function Require-Docker {
  $o = docker info 2>&1
  if ($LASTEXITCODE -ne 0 -or -not ($o -match '^Server:')) {
    throw "Docker Desktop engine is not running. Start Docker Desktop and try again."
  }
}

Require-Docker

$wrk = (Resolve-Path $PSScriptRoot).Path
$rep = (Resolve-Path (Join-Path $PSScriptRoot '..\..\reports\task')).Path
New-Item -ItemType Directory -Force $rep | Out-Null

# Pull image if needed
docker pull ghcr.io/zaproxy/zaproxy:stable | Out-Null

# Run with modest CPU/RAM to keep the system responsive
docker run --rm `
  --cpus="1.5" --memory="3g" `
  -e ZAP_JAVA_OPTS="-Xmx1024m" `
  --log-driver=none `
  -v "${wrk}:/zap/wrk" `
  -v "${rep}:/zap/wrk/reports" `
  ghcr.io/zaproxy/zaproxy:stable zap.sh -cmd -autorun "/zap/wrk/zap-task-full.yaml"

Write-Host ("Modern report: " + (Join-Path $rep 'zap-tt-modern.html'))
Write-Host ("All results (JSON): " + (Join-Path $rep 'zap-tt-all.json'))
