﻿. "$PSScriptRoot\_helpers.ps1"
$mngr = New-LoginSession 'Manager1','l/T,O,Zh~:6U'
$memb = New-LoginSession 'Member1','IXH,r\2P-|yr'

$adminUrl = 'http://host.docker.internal:8082/admin.html'
$r1 = Get-Http $adminUrl $mngr
$r2 = Get-Http $adminUrl $memb
if($r2 -and $r2.StatusCode -eq 200){
  Write-Host "RBAC FAIL: member can load admin page $adminUrl" -ForegroundColor Red
}else{
  Write-Host "RBAC OK: member blocked from admin page" -ForegroundColor Green
}

# IDOR probe (adjust to real app if needed)
$idorUrl = 'http://host.docker.internal:8082/task.html?id=1'
$mine  = Get-Http $idorUrl $memb
$yours = Get-Http $idorUrl $mngr
if($mine -and $mine.StatusCode -eq 200 -and $mine.Content -match '(?i)owner:\s*Manager1'){
  Write-Host "IDOR FAIL: Member can view Manager's task" -ForegroundColor Red
}else{
  Write-Host "IDOR check did not find obvious issue" -ForegroundColor Green
}
