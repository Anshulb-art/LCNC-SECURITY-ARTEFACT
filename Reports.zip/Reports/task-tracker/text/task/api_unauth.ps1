﻿. "$PSScriptRoot\_helpers.ps1"
$open = @()
$cands = 'http://host.docker.internal:8082/api/tasks','http://host.docker.internal:8082/api/admin/users','http://host.docker.internal:8082/api/task/1'
foreach($u in $cands){
  $r = Get-Http $u
  if($r -and $r.StatusCode -ge 200 -and $r.StatusCode -lt 300){ $open += $u }
}
if($open){ Write-Host ("API OPEN WITHOUT AUTH:`n - " + ($open -join "`n - ")) -ForegroundColor Red }
else{ Write-Host "API endpoints blocked unauth (good)" -ForegroundColor Green }
