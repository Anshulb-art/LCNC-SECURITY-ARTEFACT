﻿. "$PSScriptRoot\_helpers.ps1"
$s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
Invoke-WebRequest 'http://host.docker.internal:8082/login.html' -UseBasicParsing -TimeoutSec 10 -WebSession $s | Out-Null
$pre  = $s.Cookies.GetCookies('http://host.docker.internal:8082/') | Where-Object { $_.Name -match '(session|sid|JSESSIONID|PHPSESSID)' } | Select-Object -First 1
Invoke-WebRequest 'http://host.docker.internal:8082/login.html' -UseBasicParsing -TimeoutSec 10 -WebSession $s -Method Post -Body @{username='Member1';password='IXH,r\2P-|yr'} | Out-Null
$post = $s.Cookies.GetCookies('http://host.docker.internal:8082/') | Where-Object { $_.Name -eq $pre.Name } | Select-Object -First 1
if($pre -and $post -and $pre.Value -eq $post.Value){
  Write-Host "SESSION-FIXATION POSSIBLE (cookie unchanged: $($pre.Name))" -ForegroundColor Red
}else{
  Write-Host "Session id rotated on login (good)" -ForegroundColor Green
}
