﻿param(
  [string]$Base  = 'http://host.docker.internal:8082/',
  [string]$Login = 'http://host.docker.internal:8082/login.html'
)

function New-LoginSession([string]$u,[string]$p){
  $s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
  try{
    Invoke-WebRequest $Login -UseBasicParsing -TimeoutSec 10 -WebSession $s | Out-Null
    Invoke-WebRequest $Login -UseBasicParsing -TimeoutSec 10 -WebSession $s -Method Post -Body @{username=$u;password=$p} | Out-Null
    return $s
  } catch { return $null }
}

function Get-Http([string]$url, $s=$null){
  try{
    if($s){ Invoke-WebRequest $url -UseBasicParsing -TimeoutSec 10 -WebSession $s -ErrorAction Stop }
    else   { Invoke-WebRequest $url -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop }
  } catch { $_.Exception.Response }
}
