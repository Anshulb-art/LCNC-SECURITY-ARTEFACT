﻿param([string]$Out = 'C:\Users\anshu\tests\ZAP\task-tracker\reports\task')
New-Item -ItemType Directory -Force $Out | Out-Null
$lines = @(
  '<h2>Task Tracker – Security Checks</h2>',
  '<ul>',
  '<li><a href="zap-tt-modern.html">ZAP Modern Report</a></li>',
  '<li><a href="zap-tt-unauth.html">ZAP Unauth Report</a></li>',
  '<li><a href="zap-tt-manager.html">ZAP Manager Report</a></li>',
  '<li><a href="zap-tt-member.html">ZAP Member Report</a></li>',
  '</ul>',
  '<h3>Targeted Script Outputs</h3>',
  '<pre>',
  (powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'auth_bruteforce.ps1') | Out-String),
  (powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'auth_session_fixation.ps1') | Out-String),
  (powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'auth_bypass.ps1') | Out-String),
  (powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'rbac_idor.ps1') | Out-String),
  (powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'api_unauth.ps1') | Out-String),
  (powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'api_injection.ps1') | Out-String),
  (powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'csrf.ps1') | Out-String),
  '</pre>'
)
Set-Content -Path (Join-Path $Out 'index.html') -Value ($lines -join "`r`n") -Encoding UTF8
Write-Host "Open report:" (Join-Path $Out 'index.html')
