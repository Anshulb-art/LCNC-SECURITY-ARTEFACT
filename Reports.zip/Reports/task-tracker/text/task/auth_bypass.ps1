﻿. "$PSScriptRoot\_helpers.ps1"
$urls = 'http://host.docker.internal:8082/dashboard.html','http://host.docker.internal:8082/tasks.html'
$bad = @()
foreach($u in $urls){
  $r = Get-Http $u
  if($r -and $r.StatusCode -eq 200 -and $r.Content -notmatch '(?i)login'){
    $bad += $u
  }
}
if($bad){ Write-Host ("AUTH-BYPASS? reachable unauth:`n - " + ($bad -join "`n - ")) -ForegroundColor Red }
else { Write-Host "Protected pages require auth" -ForegroundColor Green }
