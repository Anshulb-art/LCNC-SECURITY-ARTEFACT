﻿. "$PSScriptRoot\_helpers.ps1"
$s = New-LoginSession 'Member1','IXH,r\2P-|yr'
$targetPost = 'http://host.docker.internal:8082/task-create'
try{
  $r = Invoke-WebRequest $targetPost -UseBasicParsing -TimeoutSec 10 -WebSession $s -Method Post -Body @{title='csrf-test';description='no token'} -ErrorAction Stop
  if($r.StatusCode -in 200,302){
    Write-Host "CSRF SUSPECT: action succeeded without explicit token" -ForegroundColor Red
  } else {
    Write-Host "CSRF likely enforced (status $($r.StatusCode))" -ForegroundColor Green
  }
}catch{
  Write-Host "CSRF likely enforced (request blocked / errored)." -ForegroundColor Green
}
