﻿param([string]$Target = "http://host.docker.internal:8082/")

function Require-Docker {
  $out = docker info 2>&1
  if ($LASTEXITCODE -ne 0 -or -not ($out -match "Server:")) {
    throw "Docker Desktop engine is not running."
  }
}

Require-Docker
$reports = (Join-Path (Resolve-Path "$PSScriptRoot\..\..").Path "reports\task")
New-Item -ItemType Directory -Force $reports | Out-Null

docker run --rm `
  -v "${PSScriptRoot}:/zap/wrk" `
  -v "${reports}:/zap/wrk/reports" `
  -e target="$Target" `
  ghcr.io/zaproxy/zaproxy:stable zap.sh -addoninstall accessControl -cmd -autorun "/zap/wrk/zap-task-af.yaml"

Write-Host "Open:" (Join-Path $reports "zap-tt-modern.html")

