﻿. "$PSScriptRoot\_helpers.ps1"
$candidates = 'admin','manager','password','123456','l/T,O,Zh~:6U','Welcome1!'
$hit = $null
foreach($pwd in $candidates){
  $s = New-LoginSession 'Manager1' $pwd
  if($s){
    $resp = Get-Http 'http://host.docker.internal:8082/dashboard.html' $s
    if($resp -and $resp.StatusCode -eq 200 -and $resp.Content -match '(?i)logout|dashboard'){
      $hit = $pwd; break
    }
  }
}
if($hit){ Write-Host "BF-SUCCESS password=$hit" -ForegroundColor Red } else { Write-Host "BF-NO-HIT" -ForegroundColor Green }
