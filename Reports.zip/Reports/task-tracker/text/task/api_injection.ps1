﻿. "$PSScriptRoot\_helpers.ps1"

$s = New-LoginSession 'Manager1','l/T,O,Zh~:6U'
$postUrl = 'http://host.docker.internal:8082/task-create'

# Use double-quoted strings so the single quote in the SQL-ish payload is valid.
$payloads = @(
  "' OR '1'='1",
  "<script>alert(1)</script>",
  "'); DROP TABLE tasks; --"
)

foreach($p in $payloads){
  try{
    $r = Invoke-WebRequest $postUrl -UseBasicParsing -TimeoutSec 10 -WebSession $s `
         -Method Post -Body @{ title = $p; description = 'probe' } -ErrorAction Stop

    # Simple reflected-XSS style sanity check
    if($r.Content -match [regex]::Escape($p)){
      Write-Host "Reflected output without encode (XSS risk): $p" -ForegroundColor Red
    }
  }catch{
    $resp = $_.Exception.Response
    if($resp -and $resp.StatusCode.value__ -ge 500){
      Write-Host "Server error on payload (possible injection): $p" -ForegroundColor Red
    } elseif($resp) {
      Write-Host "Non-success response ($($resp.StatusCode)) for payload: $p"
    } else {
      Write-Host "Request error for payload: $p"
    }
  }
}

Write-Host "Injection probes done."
