@echo off
setlocal

rem --- paths ---
set "WRK=C:\Users\anshu\tests\ZAP\task-tracker\text\task"
set "REP=C:\Users\anshu\tests\ZAP\task-tracker\reports\task"
if not exist "%REP%" mkdir "%REP%"

rem --- optional reachability check (won't stop the run) ---
powershell -NoProfile -Command "try { iwr 'http://host.docker.internal:8082/login.html' -UseBasicParsing -TimeoutSec 5 ^| Out-Null } catch {}"

rem --- run ZAP AF with your YAML ---
docker run --rm -it ^
  -v "%WRK%:/zap/wrk" ^
  -v "%REP%:/zap/wrk/reports" ^
  -e target="http://host.docker.internal:8082/" ^
  ghcr.io/zaproxy/zaproxy:stable zap.sh -cmd -autorun "/zap/wrk/zap-task-af.yaml"

endlocal
