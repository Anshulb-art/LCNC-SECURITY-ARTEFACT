@echo off
setlocal
docker run --rm -it ^
  -v "C:\Users\anshu\tests\ZAP\purchase-request\text\purchase:/zap/wrk" ^
  -v "C:\Users\anshu\tests\ZAP\purchase-request\reports\purchase:/zap/wrk/reports" ^
  -e target="http://host.docker.internal:8081/" ^
  ghcr.io/zaproxy/zaproxy:stable zap.sh -cmd -autorun "/zap/wrk/zap-purchase-af.yaml"
endlocal
