﻿param(
  [string]$Target = "http://host.docker.internal:8081/"
)

function Require-Docker {
  try { docker info | Out-Null } catch {
    Write-Error "Docker Desktop engine is not running. Start Docker Desktop and retry."; exit 1
  }
}
function Require-Target([string]$Base) {
  try { Invoke-WebRequest ($Base + "login.html") -UseBasicParsing -TimeoutSec 5 | Out-Null } catch {
    Write-Warning "Target not reachable at $Base (login.html). Continuing; unauth scan will still run."
  }
}

Require-Docker
Require-Target $Target

$reports = Join-Path (Resolve-Path "$PSScriptRoot\..\..") "reports\purchase"
New-Item -ItemType Directory -Force $reports | Out-Null

# Mount the text\purchase folder (YAML) and the reports folder into ZAP
docker run --rm `
  -v "${PSScriptRoot}:/zap/wrk" `
  -v "${reports}:/zap/wrk/reports" `
  -e "target=$Target" `
  ghcr.io/zaproxy/zaproxy:stable zap.sh -cmd -autorun "/zap/wrk/zap-purchase-af.yaml"

Write-Host "==> Done. Open:" (Join-Path $reports "zap-purchase-modern.html")
