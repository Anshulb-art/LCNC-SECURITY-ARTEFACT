Place your existing evidence files under ./reports/<app>/{sast|zap|ui}/
