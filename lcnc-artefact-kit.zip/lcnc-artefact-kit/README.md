# LCNC Security Artefact Kit (Manual but Reproducible)

This kit turns your **manual SAST/DAST/UI tests** into a **tangible, reproducible artefact** that examiners can verify quickly.
Artefact definition (for your thesis/defense): **“A standardized, reproducible manual security testing protocol + evidence schema, with a collector that indexes all proof into a manifest and a zipped bundle.”**

## What’s inside
- `scripts/collect-evidence.ps1` — indexes your existing reports/screenshots into `reports/MANIFEST.json` and creates `reports-<timestamp>.zip`.
- `scripts/run-all.ps1` — (optional) skeleton for future automation; keep it as **design/future work**.
- `templates/errata.md` — 1‑page Errata & Clarification you can send to your examiner.
- `templates/per-app-table.md` — copy one table per app into Chapter 4 or your handout.
- `templates/evidence-map.csv` — fill one row per finding (Claim → Endpoint → Evidence → OWASP/CWE → Severity → Mitigation).
- `templates/manifest-schema.json` — shows the expected shape of `MANIFEST.json`.
- `templates/defense-openers.txt` — 4 bullet points to open your defense with clarity.
- `reports/` — put your **existing** HTML/PNG/JSON/PDF evidence under the structure below.

## Expected report structure (place your existing outputs here)
```
reports/
  coffee/
    sast/           # SonarQube results (html/json), logs, screenshots
    zap/            # ZAP reports (html), logs
    ui/             # BugBug/Playwright screenshots, logs
  purchase/
    sast/
    zap/
    ui/
  task/
    sast/
    zap/
    ui/
```

## Quickstart
1) Move your **actual evidence files** into `reports/<app>/{sast|zap|ui}/...` (you can create subfolders per run).  
2) Open **PowerShell** in your repo root and run:
   ```powershell
   .\scripts\collect-evidence.ps1 -App all
   ```
3) This creates:
   - `reports\MANIFEST.json` (index of your top evidence files per app/tool)
   - `reports-YYYYMMDD-HHMMSS.zip` (portable bundle to share/commit)
4) Put the **zip** and **MANIFEST.json** into your Git repo. Commit and copy the **commit hash**.
5) Edit `templates/errata.md`:
   - Fill per-app tables with final truth (RBAC/IDOR/Injection/CSRF/Headers).
   - Paste your **repo URL** and **commit hash**.
   - Export to **PDF** and email it as **clarification** (not a resubmission).

## One-sentence defence
“**My artefact is a reproducible manual protocol + evidence schema with a collector that indexes all proof; the single-script orchestration is documented as design/future work.**”

---
Generated on 2025-09-08 07:59.