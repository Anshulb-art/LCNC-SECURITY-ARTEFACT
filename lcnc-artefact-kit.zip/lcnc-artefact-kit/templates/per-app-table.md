# Per‑App Findings Table (paste one per application)

| Class | Final result | Evidence (endpoint/report) | OWASP/CWE | Severity | Mitigation |
|---|---|---|---|---|---|
| RBAC | Present / Not observed | <…> | A01 / CWE-284 | H/M/L | <role/page + microflow checks> |
| IDOR | Present / Not observed | <…> | A01 / CWE-639 | H/M/L | <owner checks> |
| Injection/XSS | Present / Not observed | <…> | A03 / CWE-79/89 | H/M/L | <validate/encode> |
| CSRF | Present / Not observed | <…> | A05 / CWE-352 | H/M/L | <tokens, SameSite> |
| Headers/Info leak | <…> | <…> | A06/… | L/M | <headers, masking> |