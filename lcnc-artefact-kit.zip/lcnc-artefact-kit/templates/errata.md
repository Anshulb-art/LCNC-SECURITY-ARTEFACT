# Errata & Clarification of Findings (for submitted thesis of 06 Sep 2025)

**Author:** Anshul Bidwai · Matriculation 92113516  
**Programme:** M.Sc. Cyber Security

**Purpose.** This note clarifies wording and aligns all cross-app statements to **per-application results** already evidenced in the thesis. It also clarifies that the executed evaluation was **manual** using a standardized protocol; the single-script orchestration in the appendix is **design/future work**.

**Artefact (what the examiner can verify now).**
- A **reproducible manual testing protocol + evidence schema** (SAST, ZAP, UI) with fixed folder layout.
- A **collector script** that generates `reports/MANIFEST.json` and a zipped bundle of evidence.
- **Repo URL:** <PUT YOUR REPO URL HERE>  
- **Commit hash (tagged v1.0-submitted):** <PUT COMMIT HERE>

---

## Final results by application (single source of truth)

### Coffee Service (final)
| Class | Final result | Evidence (endpoint/file) | OWASP/CWE | Severity | Mitigation |
|---|---|---|---|---|---|
| RBAC | Not observed under tested roles | <path/to/evidence> | A01 / CWE-284 | — | Page/microflow role checks |
| IDOR | Not observed | <path/to/evidence> | A01 / CWE-639 | — | Owner checks server-side |
| Injection/XSS | <Observed/Not observed> | <path/to/evidence> | A03 / CWE-79/89 | <H/M/L> | Validate/encode |
| CSRF | <Observed/Not observed> | <path/to/evidence> | A05 / CWE-352 | <H/M/L> | Anti-CSRF tokens/SameSite |
| Headers/Info leak | <e.g., HSTS/CSP missing> | <zap section> | A06 | L/M | Harden headers |

### Purchase Request (final)
| Class | Final result | Evidence | OWASP/CWE | Severity | Mitigation |
|---|---|---|---|---|---|
| RBAC | <…> | <…> | A01 / CWE-284 | <…> | <…> |
| IDOR | <…> | <…> | A01 / CWE-639 | <…> | <…> |
| Injection/XSS | <…> | <…> | A03 / CWE-79/89 | <…> | <…> |
| CSRF | <…> | <…> | A05 / CWE-352 | <…> | <…> |
| Headers/Info leak | <…> | <…> | A06 | <…> | <…> |

### Task Tracker (final)
| Class | Final result | Evidence | OWASP/CWE | Severity | Mitigation |
|---|---|---|---|---|---|
| RBAC | **Present / bypass confirmed** | <evidence link or screenshot> | A01 / CWE-284 | **High** | Enforce role checks in microflows/pages |
| IDOR | **Present (object tampering)** | <evidence: request + 200/changed object> | A01 / CWE-639 | **High** | Owner/attribute checks |
| Injection/XSS | <Observed/Not observed> | <…> | A03 / CWE-79/89 | <H/M/L> | Validate/encode |
| CSRF | <Weak/Absent/Not observed> | <…> | A05 / CWE-352 | <H/M/L> | Tokens; SameSite |
| Headers/Info leak | <e.g., Missing HSTS or PII/hash exposure> | <…> | A06 | M | Mask sensitive fields; headers |

**Note on earlier wording.** Any text that read like “no RBAC/IDOR/injection **across all apps**” is superseded by the per‑app tables above.

**XAS/auth discrepancy (Task Tracker).**  
Different outcomes (200 vs 401) came from different **test conditions** (e.g., security level/session). The **final validated outcome** is stated in the table above; alternative conditions are noted in the appendix.