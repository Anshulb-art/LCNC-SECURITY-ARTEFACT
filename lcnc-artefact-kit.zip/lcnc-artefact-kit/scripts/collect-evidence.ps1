
param(
  [ValidateSet('coffee','purchase','task','all')]
  [string]$App = 'all'
)

$apps = if ($App -eq 'all') { @('coffee','purchase','task') } else { @($App) }
$ts = Get-Date -Format 'yyyyMMdd-HHmmss'
$manifest = [ordered]@{
  collected_at = (Get-Date).ToString('o')
  apps = @()
}

function Get-Evidence($dir) {
  if (-not (Test-Path $dir)) { return @() }
  Get-ChildItem -Path $dir -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -in '.html','.json','.pdf','.png','.jpg','.log','.md' } |
    Select-Object FullName, Length, LastWriteTime |
    Sort-Object LastWriteTime -Descending | Select-Object -First 40
}

foreach ($a in $apps) {
  $root = Join-Path "reports" $a
  $entry = [ordered]@{ app = $a; evidence = @{} }

  foreach ($tool in @('sast','zap','ui')) {
    $dir = Join-Path $root $tool
    $entry.evidence.$tool = @(Get-Evidence $dir)
  }

  $manifest.apps += $entry
}

$manifestPath = Join-Path "reports" "MANIFEST.json"
$manifest | ConvertTo-Json -Depth 8 | Set-Content -Path $manifestPath -Encoding UTF8

$zipName = "reports-$ts.zip"
if (Test-Path $zipName) { Remove-Item $zipName -Force }
Compress-Archive -Path "reports/*" -DestinationPath $zipName -Force

Write-Host "Manifest written: $manifestPath"
Write-Host "Archive created:  $zipName"
